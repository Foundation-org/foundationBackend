const route = require("express").Router();

const StartQuests = require("../models/StartQuests");
// const InfoQuestQuestions = require("../models/InfoQuestQuestions");

// SIGN UP
route.post("/createStartQuest", async (req, res) => {
  try {
    // const updateQuestion = await InfoQuestQuestions.StartQuests(
    //   {
    //     btnStatus: "completed",
    //   },
    //   {
    //     where: {
    //       walletAddr: req.body.walletAddr,
    //     },
    //   }
    // )

    await StartQuests.updateOne(
      {
        btnStatus: "completed",
      },
      {
        where: {
          walletAddr: req.body.walletAddr,
        },
      }
    );

    const question = await new StartQuests({
      questForeignKey: req.body.questForeignKey,
      walletAddr: req.body.walletAddr,
      addedAnswer: req.body.addedAnswer,
      correctAnswer: req.body.correctAnswer,
      answersSelected: req.body.answersSelected,
      // data: req.body.data,
    });

    const questions = await question.save();
    !questions && res.status(404).send("Not Created 1");

    res.status(201).send("Quest has been Created");
  } catch (err) {
    res.status(500).send("Not Created 2");
  }
});

route.post("/updateChangeAnsStartQuest", async (req, res) => {
  try {
    const startQuestQuestion = await StartQuests.findOne({
      questForeignKey: req.body.questId,
    });

    let startQuestAnswersSelected = startQuestQuestion.answersSelected;
    startQuestAnswersSelected.push(req.body.changeAnswerAddedObj);

    let responseMsg = "";

    let timeWhenUserUpdatedData = await StartQuests.findOne({
      _id: startQuestQuestion._id,
    });
    let timeWhenUserUpdated = timeWhenUserUpdatedData.updatedAt;

    let date1 = new Date();
    let date2 = date1.getTime();
    let dateFinal = date2 - timeWhenUserUpdated.getTime();

    if (dateFinal > 86400000) {
      responseMsg = "Updated";

      await StartQuests.findByIdAndUpdate(
        { _id: startQuestQuestion._id },
        { answersSelected: startQuestAnswersSelected },
        { upsert: true }
      ).exec(),
        (err, data) => {
          if (err) {
            return res.status(500).send(err);
          } else {
            return res.status(200).send(data);
          }
        };
    } else {
      responseMsg = "Wait 24 hours to update answer";
    }

    res.status(200).json(responseMsg);
  } catch (err) {
    res.status(500).send("Not Created 2");
  }
});

route.post("/getStartQuestPercent", async (req, res) => {
  try {
    const startQuestWithYes = await StartQuests.find({
      correctAnswer: "Yes",
      questForeignKey: req.body.questForeignKey,
    });

    console.log(startQuestWithYes);

    const startQuestWithNo = await StartQuests.find({
      correctAnswer: "No",
      questForeignKey: req.body.questForeignKey,
    });
    
    console.log(startQuestWithNo);

    let TotalNumberOfYesAns = startQuestWithYes === null ? 0 : startQuestWithYes.length;
    let TotalNumberOfNoAns = startQuestWithNo === null ? 0 : startQuestWithNo.length;

    let TotalNumberOfAns = TotalNumberOfYesAns + TotalNumberOfNoAns;
    console.log("TotalNumberOfAns", TotalNumberOfAns);

    let percentageOfYesAns = TotalNumberOfYesAns === 0 ? 0 : (TotalNumberOfYesAns * 100) / TotalNumberOfAns;
    console.log("startQuestWithYes", percentageOfYesAns);

    let percentageOfNoAns = TotalNumberOfNoAns === 0 ? 0 : (TotalNumberOfNoAns * 100) / TotalNumberOfAns;
    console.log("startQuestWithNo", percentageOfNoAns);

    res
      .status(200)
      .json([
        { Yes: percentageOfYesAns === NaN ? 0 : percentageOfYesAns },
        { No: percentageOfNoAns === NaN ? 0 : percentageOfNoAns },
      ]);
  } catch (err) {
    res.status(500).send("Not Created 2");
  }
});

module.exports = route;
